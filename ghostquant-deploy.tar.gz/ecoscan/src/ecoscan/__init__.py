"""GhostQuant Ecoscan - Ecosystem Mapper + Whale Intelligence."""

__version__ = "0.1.0"
