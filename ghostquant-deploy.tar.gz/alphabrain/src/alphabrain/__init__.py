"""
GhostQuant AlphaBrain - Quant Intelligence Module

Institutional-grade analytics inspired by Harvard finance education
and elite hedge-fund processes.
"""

__version__ = "0.1.0"
